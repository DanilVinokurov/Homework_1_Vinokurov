import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        //Начало фраз разделителей
        String razdel;
        //Конец фраз разделителей
        // пример:
        razdel = "Первый пример";
        System.out.println(razdel);
        int myHomeNumber = 10;
        System.out.println(myHomeNumber);
        // пример 2:
        razdel = "Второй пример";
        System.out.println(razdel);
        int age = 19;
        String name = "Bob", lastName;
        lastName = "Johnson";
        System.out.println(name);
        System.out.println(lastName);
        System.out.println(age);
        //пример присваивания других значении
        razdel = "Пример присвайвания других значений";
        System.out.println(razdel);
        name = "Bill";
        System.out.println(name);
        //пример переменная класса
        razdel = "Не видно, но на этом моменте появился класс";
        System.out.println(razdel);
        class MyClass {
            String classVariable = "Область видимости данных, я в MYclass";
            //Область видимости переменных
        }
        //Арефметические выражения пример 1
        razdel = "Пример Арефметических выражений";
        System.out.println(razdel);
        int x1 = 5, y1 = 2, z = 3;
        int resultMathOrder = x1 - y1 * z; // -1
        int resultCustomOrder = (x1 - y1) * z; // 9
        System.out.println (resultMathOrder);
        System.out.println (resultCustomOrder);
        razdel = "Пример Арефметических выражений 2, но первый два int, а последнее double от точного к более точному можно, НО НЕ НА ОБОРОТ!";
        System.out.println(razdel);
        int a = 5;
        int b = 10;
        double c = a + b;
        System.out.println (c);
        razdel = "Пример? Нет не слабо вставить чесно вот, правда с некими изменениями. Но почему именно так?";
        System.out.println(razdel);
        byte x = 2;
        //тут
        byte y = (byte) (x + 2);
        System.out.println (resultMathOrder);
        razdel = "Ответ на следующем слайде... Вот ответ - выше это явное применение типов ссылка на (тут)";
        System.out.println(razdel);
        razdel = "Пример почему из double мы смогли сделать int";
        System.out.println(razdel);
        double a1 = 10.3;
        double b1 = 9.8;
        int c1 = (int)a1 + (int)b1;
        int d = (int)(a1 + b1);
        System.out.println(c1);
        System.out.println(d);
        razdel = "Ответ я претпологая что 10.3 и 9.8 округляются под воздействием цело\n численных типов данных и потом просто складываются";
        System.out.println(razdel);
        razdel = "Для чего нужны следующие типы данных\n byte = Целые числа от -128 до 127\n short = Целые числа от -32 768 до 32 767\n int = Целые числа от -2 147 483 648 до 2 147 483 647" +
                "\n long = Целые числа от -2⁶⁴ до 2⁶⁴-1\n float = Дробные числа 6-7 разрядов\n double = Дробные числа 15 разрядов\n boolean = true или false\n char = один символ/буква или код ASCII\n" ;
        System.out.println(razdel);
        razdel = "Пример сложения строк";
        System.out.println(razdel);
        String firstString= "Hello, ";
        String secondString = "My name is Vadim";
        String sumOfTwoStrings = firstString + secondString;
        System.out.println(sumOfTwoStrings);
        razdel = "Пример полезного метода string позволяет вернуть длинну строки (число). Ниже уже подсчитана длинна этого razdel";
        System.out.println(razdel);
        razdel.length();
        razdel = "Там еще много примеров, а время поджимает, но я с ними ознакомился!\n Привет я из будущего иформация об этом хранится на дополнительных курсах у нас в папке";
        System.out.println(razdel);
        razdel = "Домашняя работа";
        System.out.println(razdel);
        name = "Я Винокуров Данил студент";
        System.out.println(name);
        byte q = 127;
        name = "byte ";
        System.out.println(name+q);
        short w = 32767;
        name = "short ";
        System.out.println(name+w);
        int e = 2147483647;
        name = "int ";
        System.out.println(name+e);
        long r= 1844674407;
        name = "long ";
        System.out.println(name+r);
        float t = 1/7;
        name = "float ";
        System.out.println(name+t);
        double y3= 1.111111111111111;
        name = "double ";
        System.out.println(name+y3);
        boolean u=true;
        name = "boolean ";
        System.out.println(name+u);
        char i = (char) t;
        name = "char ";
        System.out.println(name+i);
        razdel = "Строка 79, меня переиграли и уничтожили";
        System.out.println(razdel);
        razdel = "Введи число";
        System.out.println(razdel);
        Scanner scanner = new Scanner(System.in);
        String str = scanner.nextLine();
        System.out.println(str);
        razdel = "Пример сложения строк";
        System.out.println(razdel);
        System.out.println(sumOfTwoStrings);
        razdel = "Пример полезного метода string позволяет вернуть длинну строки (число). Ниже уже подсчитана длинна этого razdel";
        System.out.println(razdel);
        System.out.println(razdel.length());
        razdel = "Пример полезного метода string Возвращает true, если строка пустая, false - если нет";
        System.out.println(razdel);
        String myString = "This is my string, there are many like it but this one is mine";
        System.out.println(myString.isEmpty());
        razdel = "Пример полезного метода string Возвращает символ строки по индексу (тип char)";
        System.out.println(razdel);
        myString = "This is my string, there are many like it but this one is mine";
        System.out.println(myString.charAt(7));

        razdel = "Пример полезного метода string Полезню методу класса String: public boolean equals(Object anObject)"
                +"Возвращает true, если строки одинаковю, false - если нет\n";
        System.out.println(razdel);
         myString = "This is my string, there are many like it but this one is mine";
        String anotherString = "This one is not the same";
        boolean areEqual = myString.equals(anotherString);
        System.out.println (areEqual);

        razdel = "Пример полезного метода string Возвращает true, если строки одинаковы, независимо \n" +
                "от регистра, false - если нет\n";
        System.out.println(razdel);
        myString = "This is my string, there are many like it but this one is mine";
        String lowercase = "this is my string, there are many like it but this one is mine";
        areEqual = myString.equalsIgnoreCase(lowercase);
        System.out.println (areEqual);

        razdel = "Пример полезного метода string Возвращает true, если строка начинается с указанного" +
                "набора символов, false - если нет";
        System.out.println(razdel);
        myString = "This is my string, there are many like it but this one is mine";
        boolean startsWithThis = myString.startsWith("This");
        boolean startsWithMyOffset8 = myString.startsWith("my", 8);
        System.out.println (startsWithThis);
        System.out.println (startsWithMyOffset8);
        razdel = "Пример полезного метода string Возвращает true, если строка заканчивается " +
                "указанным набором символов, false - если нет";
        System.out.println(razdel);
        myString = "This is my string, there are many like it but this one is mine";
        boolean endsWithMine = myString.endsWith("mine");
        System.out.println (endsWithMine);
        razdel = "Пример полезного метода string Возвращает true, если строка содержит в себе \n" +
                "указанный набор символов, false - если нет\n";
        System.out.println(razdel);
        boolean containsMany = myString.contains("many");
        System.out.println (containsMany);
        razdel = "Пример полезного метода string Возвращает результирующую строку, состоящую из " +
                "первоначальной, с добавлением в ее конец новой";
        System.out.println(razdel);
        String newString = myString.concat(". The end");
        System.out.println (newString);
        razdel = "Пример полезного метода string Возвращает результирующую строку, в которой все " +
                "символы или их сочетания заменены на указанные";
        System.out.println(razdel);
         newString = myString.replace('i', 'a');
        String newerString = myString.replace("re", " ");
        System.out.println (newString);
        System.out.println (newerString);
        razdel = "Пример полезного метода string Возвращает исходную строку в нижнем регистре";
        System.out.println(razdel);
        String myStringInLowerCase = myString.toLowerCase();
        System.out.println (myStringInLowerCase);
        razdel = "Пример полезного метода string Возвращает строку, где сочетания %- заменены на " +
                "принимаемые параметры";
        System.out.println(razdel);
        String homeStreet = "Ivanova Str.";
        int houseNr = 10;
        int flatNr = 56;
        String myAddress = String.format("I live at %s, house %d, flat %d", homeStreet, houseNr, flatNr);
        System.out.println (myAddress);
        razdel = "Пример полезного метода string Изменяемый вариант строки";
        System.out.println(razdel);
        razdel = "StringBuffer buffer = My name is;"+
        "buffer.append( Vadim);"+ "И тут мнооого ошибок";
        System.out.println(razdel);





    }
}