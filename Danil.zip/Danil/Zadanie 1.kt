object Main {
    @JvmStatic
    fun main(args: Array<String>) {
        kotlin.io.println("Hello world!")
        //Начало фраз разделителей
        var razdel: String
        //Конец фраз разделителей
        // пример:
        razdel = "Первый пример"
        kotlin.io.println(razdel)
        val myHomeNumber = 10
        kotlin.io.println(myHomeNumber)
        // пример 2:
        razdel = "Второй пример"
        kotlin.io.println(razdel)
        val age = 19
        var name = "Bob"
        val lastName: String
        lastName = "Johnson"
        kotlin.io.println(name)
        kotlin.io.println(lastName)
        kotlin.io.println(age)
        //пример присваивания других значении
        razdel = "Пример присвайвания других значений"
        kotlin.io.println(razdel)
        name = "Bill"
        kotlin.io.println(name)
        //пример переменная класса
        razdel = "Не видно, но на этом моменте появился класс"
        kotlin.io.println(razdel)
        class MyClass {
            var classVariable = "Область видимости данных, я в MYclass" //Область видимости переменных
        }
        //Арефметические выражения пример 1
        razdel = "Пример Арефметических выражений"
        kotlin.io.println(razdel)
        val x1 = 5
        val y1 = 2
        val z = 3
        val resultMathOrder = x1 - y1 * z // -1
        val resultCustomOrder = (x1 - y1) * z // 9
        kotlin.io.println(resultMathOrder)
        kotlin.io.println(resultCustomOrder)
        razdel =
            "Пример Арефметических выражений 2, но первый два int, а последнее double от точного к более точному можно, НО НЕ НА ОБОРОТ!"
        kotlin.io.println(razdel)
        val a = 5
        val b = 10
        val c = (a + b).toDouble()
        kotlin.io.println(c)
        razdel = "Пример? Нет не слабо вставить чесно вот, правда с некими изменениями. Но почему именно так?"
        kotlin.io.println(razdel)
        val x: Byte = 2
        //тут
        val y = (x + 2).toByte()
        kotlin.io.println(resultMathOrder)
        razdel = "Ответ на следующем слайде... Вот ответ - выше это явное применение типов ссылка на (тут)"
        kotlin.io.println(razdel)
        razdel = "Пример почему из double мы смогли сделать int"
        kotlin.io.println(razdel)
        val a1 = 10.3
        val b1 = 9.8
        val c1 = a1.toInt() + b1.toInt()
        val d = (a1 + b1).toInt()
        kotlin.io.println(c1)
        kotlin.io.println(d)
        razdel =
            "Ответ я претпологая что 10.3 и 9.8 округляются под воздействием цело\n численных типов данных и потом просто складываются"
        kotlin.io.println(razdel)
        razdel = """Для чего нужны следующие типы данных
 byte = Целые числа от -128 до 127
 short = Целые числа от -32 768 до 32 767
 int = Целые числа от -2 147 483 648 до 2 147 483 647
 long = Целые числа от -2⁶⁴ до 2⁶⁴-1
 float = Дробные числа 6-7 разрядов
 double = Дробные числа 15 разрядов
 boolean = true или false
 char = один символ/буква или код ASCII
"""
        kotlin.io.println(razdel)
        razdel = "Пример сложения строк"
        kotlin.io.println(razdel)
        val firstString = "Hello, "
        val secondString = "My name is Vadim"
        val sumOfTwoStrings = firstString + secondString
        kotlin.io.println(sumOfTwoStrings)
        razdel =
            "Пример полезного метода string позволяет вернуть длинну строки (число). Ниже уже подсчитана длинна этого razdel"
        kotlin.io.println(razdel)
        razdel.length
        razdel =
            "Там еще много примеров, а время поджимает, но я с ними ознакомился!\n Привет я из будущего иформация об этом хранится на дополнительных курсах у нас в папке"
        kotlin.io.println(razdel)
        razdel = "Домашняя работа"
        kotlin.io.println(razdel)
        name = "Я Винокуров Данил студент"
        kotlin.io.println(name)
        val q: Byte = 127
        name = "byte "
        kotlin.io.println(name + q)
        val w: Short = 32767
        name = "short "
        kotlin.io.println(name + w)
        val e = 2147483647
        name = "int "
        kotlin.io.println(name + e)
        val r: Long = 1844674407
        name = "long "
        kotlin.io.println(name + r)
        val t = (1 / 7).toFloat()
        name = "float "
        kotlin.io.println(name + t)
        val y3 = 1.111111111111111
        name = "double "
        kotlin.io.println(name + y3)
        val u = true
        name = "boolean "
        kotlin.io.println(name + u)
        val i = t.toInt().toChar()
        name = "char "
        kotlin.io.println(name + i)
        razdel = "Строка 79, меня переиграли и уничтожили"
        kotlin.io.println(razdel)
        razdel = "Введи число"
        kotlin.io.println(razdel)
        val scanner: java.util.Scanner = java.util.Scanner(java.lang.System.`in`)
        val str: String = scanner.nextLine()
        kotlin.io.println(str)
        razdel = "Пример сложения строк"
        kotlin.io.println(razdel)
        kotlin.io.println(sumOfTwoStrings)
        razdel =
            "Пример полезного метода string позволяет вернуть длинну строки (число). Ниже уже подсчитана длинна этого razdel"
        kotlin.io.println(razdel)
        kotlin.io.println(razdel.length)
        razdel = "Пример полезного метода string Возвращает true, если строка пустая, false - если нет"
        kotlin.io.println(razdel)
        var myString = "This is my string, there are many like it but this one is mine"
        kotlin.io.println(myString.isEmpty())
        razdel = "Пример полезного метода string Возвращает символ строки по индексу (тип char)"
        kotlin.io.println(razdel)
        myString = "This is my string, there are many like it but this one is mine"
        kotlin.io.println(myString[7])
        razdel = """
            Пример полезного метода string Полезню методу класса String: public boolean equals(Object anObject)Возвращает true, если строки одинаковю, false - если нет
            
            """.trimIndent()
        kotlin.io.println(razdel)
        myString = "This is my string, there are many like it but this one is mine"
        val anotherString = "This one is not the same"
        var areEqual = myString == anotherString
        kotlin.io.println(areEqual)
        razdel = "Пример полезного метода string Возвращает true, если строки одинаковы, независимо \n" +
                "от регистра, false - если нет\n"
        kotlin.io.println(razdel)
        myString = "This is my string, there are many like it but this one is mine"
        val lowercase = "this is my string, there are many like it but this one is mine"
        areEqual = myString.equals(lowercase, ignoreCase = true)
        kotlin.io.println(areEqual)
        razdel = "Пример полезного метода string Возвращает true, если строка начинается с указанного" +
                "набора символов, false - если нет"
        kotlin.io.println(razdel)
        myString = "This is my string, there are many like it but this one is mine"
        val startsWithThis: Boolean = myString.startsWith("This")
        val startsWithMyOffset8: Boolean = myString.startsWith("my", 8)
        kotlin.io.println(startsWithThis)
        kotlin.io.println(startsWithMyOffset8)
        razdel = "Пример полезного метода string Возвращает true, если строка заканчивается " +
                "указанным набором символов, false - если нет"
        kotlin.io.println(razdel)
        myString = "This is my string, there are many like it but this one is mine"
        val endsWithMine: Boolean = myString.endsWith("mine")
        kotlin.io.println(endsWithMine)
        razdel = "Пример полезного метода string Возвращает true, если строка содержит в себе \n" +
                "указанный набор символов, false - если нет\n"
        kotlin.io.println(razdel)
        val containsMany: Boolean = myString.contains("many")
        kotlin.io.println(containsMany)
        razdel = "Пример полезного метода string Возвращает результирующую строку, состоящую из " +
                "первоначальной, с добавлением в ее конец новой"
        kotlin.io.println(razdel)
        var newString: String? = "$myString. The end"
        kotlin.io.println(newString)
        razdel = "Пример полезного метода string Возвращает результирующую строку, в которой все " +
                "символы или их сочетания заменены на указанные"
        kotlin.io.println(razdel)
        newString = myString.replace('i', 'a')
        val newerString: String = myString.replace("re", " ")
        kotlin.io.println(newString)
        kotlin.io.println(newerString)
        razdel = "Пример полезного метода string Возвращает исходную строку в нижнем регистре"
        kotlin.io.println(razdel)
        val myStringInLowerCase: String = myString.lowercase(Locale.getDefault())
        kotlin.io.println(myStringInLowerCase)
        razdel = "Пример полезного метода string Возвращает строку, где сочетания %- заменены на " +
                "принимаемые параметры"
        kotlin.io.println(razdel)
        val homeStreet = "Ivanova Str."
        val houseNr = 10
        val flatNr = 56
        val myAddress: String = String.format("I live at %s, house %d, flat %d", homeStreet, houseNr, flatNr)
        kotlin.io.println(myAddress)
        razdel = "Пример полезного метода string Изменяемый вариант строки"
        kotlin.io.println(razdel)
        razdel = "StringBuffer buffer = My name is;" +
                "buffer.append( Vadim);" + "И тут мнооого ошибок"
        kotlin.io.println(razdel)
    }
}